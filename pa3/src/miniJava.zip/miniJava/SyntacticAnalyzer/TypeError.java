package miniJava.SyntacticAnalyzer;

public class TypeError extends Exception {
	private static final long serialVersionUID = 2583239898992018218L;
	public TypeError() {
		super();
	};
	public TypeError (String s) {
		super(s);
	}

}